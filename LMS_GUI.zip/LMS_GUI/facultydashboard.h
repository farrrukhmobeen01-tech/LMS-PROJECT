#ifndef FACULTYDASHBOARD_H
#define FACULTYDASHBOARD_H

#include <QDialog>
#include <QTabWidget>
#include <QTableWidget>
#include <QComboBox>
#include <QLineEdit>
#include "Portal.h"

class FacultyDashboard : public QDialog
{
    Q_OBJECT

public:
    explicit FacultyDashboard(Portal *system, int index, QWidget *parent = nullptr);
    ~FacultyDashboard();

private slots:
    void refreshAll();
    void markPresent();
    void updateGrade();
    void uploadContent();

    // --- YE WO FUNCTIONS HAIN JO MISSING THAY ---
    void loadAttendanceData();
    void loadGradingData();
    void loadStudentViewData();
    void loadFeedbackData();

private:
    Portal *sys;
    int facIndex;
    QTabWidget *tabs;

    // UI Widgets
    QComboBox *cbAttend, *cbGrade, *cbView, *cbFeed, *cbUploadSub, *cbUploadType;
    QTableWidget *tbAttend, *tbGrade, *tbView, *tbFeed;
    QLineEdit *inGrade, *inUpload;

    void setupAllocations();
    void setupAttendance();
    void setupGrading();
    void setupStudentsView();
    void setupFeedbacks();
    void setupUploads();
};

#endif // FACULTYDASHBOARD_H
