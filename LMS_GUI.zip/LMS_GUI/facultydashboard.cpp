#include "facultydashboard.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QHeaderView>

FacultyDashboard::FacultyDashboard(Portal *system, int index, QWidget *parent)
    : QDialog(parent), sys(system), facIndex(index)
{
    setWindowState(Qt::WindowMaximized);

    // Styling
    setStyleSheet(R"(
        QDialog { background-color: #F4F7F6; }
        QTabWidget::pane { border: 1px solid #ccc; background: white; border-radius: 5px; }
        QTabBar::tab { background: #E0E0E0; padding: 12px 25px; font-weight: bold; font-size: 15px; margin-right: 2px; }
        QTabBar::tab:selected { background: #4527A0; color: white; }
        QTableWidget { background: white; border: 1px solid #ccc; font-size: 15px; }
        QHeaderView::section { background-color: #311B92; color: white; padding: 8px; font-weight: bold; }
        QPushButton { background-color: #4527A0; color: white; padding: 10px; border-radius: 5px; font-weight: bold; font-size: 14px; }
        QPushButton:hover { background-color: #311B92; }
        QLabel { font-size: 16px; color: #333; }
        QLineEdit, QComboBox { padding: 8px; font-size: 15px; border: 1px solid #ccc; border-radius: 4px; }
    )");

    setWindowTitle("Faculty Portal");

    QVBoxLayout *main = new QVBoxLayout(this);
    main->setContentsMargins(20, 20, 20, 20);

    // Header
    QHBoxLayout *top = new QHBoxLayout();
    QLabel *lbl = new QLabel("Faculty Dashboard  |  " + QString::fromStdString(sys->facList[facIndex].fullName));
    lbl->setStyleSheet("font-size: 26px; font-weight: 900; color: #311B92;");
    QPushButton *out = new QPushButton("LOGOUT");
    out->setStyleSheet("background-color: #C62828; color: white;");
    connect(out, &QPushButton::clicked, this, &QDialog::accept);
    top->addWidget(lbl); top->addStretch(); top->addWidget(out);
    main->addLayout(top);
    main->addSpacing(15);

    tabs = new QTabWidget();
    setupAllocations();
    setupAttendance();
    setupGrading();
    setupStudentsView();
    setupFeedbacks();
    setupUploads();

    main->addWidget(tabs);
}

FacultyDashboard::~FacultyDashboard() {}

void FacultyDashboard::refreshAll() {
    loadAttendanceData();
    loadGradingData();
    loadStudentViewData();
    loadFeedbackData();
}

void FacultyDashboard::setupAllocations() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);
    QTableWidget *t = new QTableWidget();
    t->setColumnCount(2);
    t->setHorizontalHeaderLabels({"Course Code", "Course Name"});
    t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    t->setAlternatingRowColors(true);
    Faculty &f = sys->facList[facIndex];
    t->setRowCount(f.allocCount);
    for(int i=0; i<f.allocCount; i++) {
        string code = f.allocs[i];
        int ci = sys->findSubject(code);
        t->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(code)));
        t->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(ci!=-1 ? sys->subjects[ci].subName : "")));
    }
    l->addWidget(new QLabel("My Allocated Courses:")); l->addWidget(t);
    tabs->addTab(w, "Allocations");
}

void FacultyDashboard::setupAttendance() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);
    cbAttend = new QComboBox();
    Faculty &f = sys->facList[facIndex];
    for(int i=0; i<f.allocCount; i++) cbAttend->addItem(QString::fromStdString(f.allocs[i]));

    tbAttend = new QTableWidget();
    tbAttend->setColumnCount(3);
    tbAttend->setHorizontalHeaderLabels({"Student ID", "Total Sessions", "Present Count"});
    tbAttend->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tbAttend->setAlternatingRowColors(true);

    QPushButton *btn = new QPushButton("Mark Selected Student Present (+1)");
    btn->setStyleSheet("background-color: #2E7D32; color: white;");

    l->addWidget(new QLabel("Select Course:")); l->addWidget(cbAttend);
    l->addWidget(tbAttend); l->addWidget(btn);

    connect(cbAttend, &QComboBox::currentTextChanged, this, &FacultyDashboard::loadAttendanceData);
    connect(btn, &QPushButton::clicked, this, &FacultyDashboard::markPresent);

    if(f.allocCount > 0) loadAttendanceData();
    tabs->addTab(w, "Attendance");
}

void FacultyDashboard::loadAttendanceData() {
    string code = cbAttend->currentText().toStdString();
    int ci = sys->findSubject(code);
    if(ci == -1) { tbAttend->setRowCount(0); return; }
    Subject &sub = sys->subjects[ci];
    tbAttend->setRowCount(sub.joinCount);
    for(int i=0; i<sub.joinCount; i++) {
        tbAttend->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sub.joined[i])));
        tbAttend->setItem(i,1,new QTableWidgetItem(QString::number(sub.sessions)));
        tbAttend->setItem(i,2,new QTableWidgetItem(QString::number(sub.presence[i])));
    }
}

void FacultyDashboard::markPresent() {
    int r = tbAttend->currentRow();
    if(r < 0) { QMessageBox::warning(this, "Error", "Select a student first."); return; }
    int ci = sys->findSubject(cbAttend->currentText().toStdString());
    if(ci != -1) {
        sys->subjects[ci].presence[r]++;
        if(sys->subjects[ci].sessions == 0) sys->subjects[ci].sessions = 1;
        loadAttendanceData();
        QMessageBox::information(this, "Success", "Marked Present");
    }
}

void FacultyDashboard::setupGrading() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);
    cbGrade = new QComboBox();
    Faculty &f = sys->facList[facIndex];
    for(int i=0; i<f.allocCount; i++) cbGrade->addItem(QString::fromStdString(f.allocs[i]));

    tbGrade = new QTableWidget();
    tbGrade->setColumnCount(2);
    tbGrade->setHorizontalHeaderLabels({"Student ID", "Current Grade"});
    tbGrade->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tbGrade->setAlternatingRowColors(true);

    inGrade = new QLineEdit(); inGrade->setPlaceholderText("Enter Grade");
    QPushButton *btn = new QPushButton("Update Grade");

    l->addWidget(new QLabel("Select Course:")); l->addWidget(cbGrade); l->addWidget(tbGrade);
    QHBoxLayout *h = new QHBoxLayout(); h->addWidget(new QLabel("Grade:")); h->addWidget(inGrade); h->addWidget(btn);
    l->addLayout(h);

    connect(cbGrade, &QComboBox::currentTextChanged, this, &FacultyDashboard::loadGradingData);
    connect(btn, &QPushButton::clicked, this, &FacultyDashboard::updateGrade);
    if(f.allocCount > 0) loadGradingData();
    tabs->addTab(w, "Grading");
}

void FacultyDashboard::loadGradingData() {
    int ci = sys->findSubject(cbGrade->currentText().toStdString());
    if(ci == -1) { tbGrade->setRowCount(0); return; }
    Subject &sub = sys->subjects[ci];
    tbGrade->setRowCount(sub.joinCount);
    for(int i=0; i<sub.joinCount; i++) {
        tbGrade->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sub.joined[i])));
        tbGrade->setItem(i,1,new QTableWidgetItem(QString::fromStdString(sub.scores[i])));
    }
}

void FacultyDashboard::updateGrade() {
    int r = tbGrade->currentRow();
    if(r < 0) return;
    int ci = sys->findSubject(cbGrade->currentText().toStdString());
    if(ci != -1) {
        sys->subjects[ci].scores[r] = inGrade->text().toStdString();
        loadGradingData();
        QMessageBox::information(this,"Success","Grade Saved");
    }
}

void FacultyDashboard::setupStudentsView() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);
    cbView = new QComboBox();
    Faculty &f = sys->facList[facIndex];
    for(int i=0; i<f.allocCount; i++) cbView->addItem(QString::fromStdString(f.allocs[i]));

    tbView = new QTableWidget();
    tbView->setColumnCount(2);
    tbView->setHorizontalHeaderLabels({"Roll No", "Full Name"});
    tbView->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tbView->setAlternatingRowColors(true);

    l->addWidget(new QLabel("Select Course:")); l->addWidget(cbView); l->addWidget(tbView);
    connect(cbView, &QComboBox::currentTextChanged, this, &FacultyDashboard::loadStudentViewData);
    if(f.allocCount > 0) loadStudentViewData();
    tabs->addTab(w, "Enrolled Students");
}

void FacultyDashboard::loadStudentViewData() {
    int ci = sys->findSubject(cbView->currentText().toStdString());
    if(ci == -1) { tbView->setRowCount(0); return; }
    Subject &sub = sys->subjects[ci];
    tbView->setRowCount(sub.joinCount);
    for(int i=0; i<sub.joinCount; i++) {
        string sid = sub.joined[i];
        int si = sys->findStudent(sid);
        string name = (si != -1) ? sys->students[si].fullName : "Unknown";
        tbView->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sid)));
        tbView->setItem(i,1,new QTableWidgetItem(QString::fromStdString(name)));
    }
}

void FacultyDashboard::setupFeedbacks() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);
    cbFeed = new QComboBox();
    Faculty &f = sys->facList[facIndex];
    for(int i=0; i<f.allocCount; i++) cbFeed->addItem(QString::fromStdString(f.allocs[i]));

    tbFeed = new QTableWidget();
    tbFeed->setColumnCount(1);
    tbFeed->setHorizontalHeaderLabels({"Feedback Message"});
    tbFeed->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tbFeed->setAlternatingRowColors(true);

    l->addWidget(new QLabel("Select Course:")); l->addWidget(cbFeed); l->addWidget(tbFeed);
    connect(cbFeed, &QComboBox::currentTextChanged, this, &FacultyDashboard::loadFeedbackData);
    if(f.allocCount > 0) loadFeedbackData();
    tabs->addTab(w, "Feedbacks");
}

void FacultyDashboard::loadFeedbackData() {
    int ci = sys->findSubject(cbFeed->currentText().toStdString());
    if(ci == -1) { tbFeed->setRowCount(0); return; }
    Subject &sub = sys->subjects[ci];
    tbFeed->setRowCount(sub.reviewCount);
    for(int i=0; i<sub.reviewCount; i++) {
        tbFeed->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sub.reviews[i])));
    }
}

void FacultyDashboard::setupUploads() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);
    cbUploadSub = new QComboBox();
    Faculty &f = sys->facList[facIndex];
    for(int i=0; i<f.allocCount; i++) cbUploadSub->addItem(QString::fromStdString(f.allocs[i]));

    cbUploadType = new QComboBox(); cbUploadType->addItem("Lecture Note"); cbUploadType->addItem("Assignment");
    inUpload = new QLineEdit(); inUpload->setPlaceholderText("Enter content text here...");
    QPushButton *btn = new QPushButton("Upload Content");

    l->addWidget(new QLabel("Course:")); l->addWidget(cbUploadSub);
    l->addWidget(new QLabel("Content Type:")); l->addWidget(cbUploadType);
    l->addWidget(new QLabel("Content:")); l->addWidget(inUpload);
    l->addWidget(btn); l->addStretch();

    connect(btn, &QPushButton::clicked, this, &FacultyDashboard::uploadContent);
    tabs->addTab(w, "Uploads");
}

void FacultyDashboard::uploadContent() {
    int ci = sys->findSubject(cbUploadSub->currentText().toStdString());
    if(ci != -1 && !inUpload->text().isEmpty()) {
        if(cbUploadType->currentIndex() == 0) sys->subjects[ci].addNote(inUpload->text().toStdString());
        else sys->subjects[ci].addTask(inUpload->text().toStdString());
        QMessageBox::information(this,"Success","Content Uploaded");
        inUpload->clear();
    }
}
