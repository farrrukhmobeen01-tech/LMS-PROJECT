#include "admindashboard.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QHeaderView>
#include <QGroupBox>
#include <QFormLayout>

AdminDashboard::AdminDashboard(Portal *system, QWidget *parent)
    : QDialog(parent), sys(system)
{
    setWindowState(Qt::WindowMaximized);

    setStyleSheet(R"(
        QDialog { background-color: #F4F7F6; }

        QTabWidget::pane { border: 1px solid #ccc; background: white; }
        QTabBar::tab {
            background: #E0E0E0; padding: 12px 30px; font-weight: bold; font-size: 16px;
            border-top-left-radius: 5px; border-top-right-radius: 5px; margin-right: 2px;
        }
        QTabBar::tab:selected { background: #283593; color: white; } /* Indigo */

        QTableWidget { background: white; border: 1px solid #ccc; font-size: 14px; }
        QHeaderView::section { background-color: #1A237E; color: white; padding: 8px; font-size: 14px; font-weight: bold; }

        QPushButton { background-color: #283593; color: white; padding: 10px; border-radius: 5px; font-weight: bold; }
        QPushButton:hover { background-color: #1A237E; }

        QPushButton#DelBtn { background-color: #C62828; }
        QPushButton#AddBtn { background-color: #2E7D32; }

        QLineEdit, QComboBox { padding: 8px; border: 1px solid #ccc; border-radius: 4px; font-size: 14px; }
        QGroupBox { border: 1px solid #aaa; margin-top: 20px; font-weight: bold; font-size: 16px; color: #283593; }
        QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 5px; }
    )");

    setWindowTitle("Admin Control Panel");

    QVBoxLayout *main = new QVBoxLayout(this);
    main->setContentsMargins(20,20,20,20);

    // Header
    QHBoxLayout *top = new QHBoxLayout();
    QLabel *lbl = new QLabel("ADMINISTRATOR DASHBOARD");
    lbl->setStyleSheet("font-size: 28px; font-weight: 900; color: #1A237E;");
    QPushButton *out = new QPushButton("LOGOUT");
    out->setStyleSheet("background-color: #C62828;");
    connect(out, &QPushButton::clicked, this, &QDialog::accept);

    top->addWidget(lbl); top->addStretch(); top->addWidget(out);
    main->addLayout(top);
    main->addSpacing(10);

    tabs = new QTabWidget();
    setupUsersTab();
    setupCoursesTab();
    setupAllocTab();

    main->addWidget(tabs);
    refreshAll();
}

AdminDashboard::~AdminDashboard() {}

void AdminDashboard::refreshAll() {
    // Refresh Logic (Same as before but cleaner tables)
    tbStd->setRowCount(sys->stdCount);
    for(int i=0; i<sys->stdCount; i++) {
        tbStd->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sys->students[i].rollNo)));
        tbStd->setItem(i,1,new QTableWidgetItem(QString::fromStdString(sys->students[i].fullName)));
        tbStd->setItem(i,2,new QTableWidgetItem(QString::fromStdString(sys->students[i].getID())));
    }

    tbFac->setRowCount(sys->facCount);
    for(int i=0; i<sys->facCount; i++) {
        tbFac->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sys->facList[i].empID)));
        tbFac->setItem(i,1,new QTableWidgetItem(QString::fromStdString(sys->facList[i].fullName)));
    }

    tbCourse->setRowCount(sys->subCount);
    cbAssignCourse->clear(); cbEnrollCourse->clear();
    for(int i=0; i<sys->subCount; i++) {
        tbCourse->setItem(i,0,new QTableWidgetItem(QString::fromStdString(sys->subjects[i].subCode)));
        tbCourse->setItem(i,1,new QTableWidgetItem(QString::fromStdString(sys->subjects[i].subName)));
        tbCourse->setItem(i,2,new QTableWidgetItem(QString::fromStdString(sys->subjects[i].facID)));

        cbAssignCourse->addItem(QString::fromStdString(sys->subjects[i].subCode));
        cbEnrollCourse->addItem(QString::fromStdString(sys->subjects[i].subCode));
    }

    cbAssignFac->clear();
    for(int i=0; i<sys->facCount; i++) cbAssignFac->addItem(QString::fromStdString(sys->facList[i].empID));
}

void AdminDashboard::setupUsersTab() {
    QWidget *w = new QWidget(); QHBoxLayout *l = new QHBoxLayout(w);

    // Left
    QWidget *left = new QWidget(); QVBoxLayout *ll = new QVBoxLayout(left);
    tbStd = new QTableWidget(); tbStd->setColumnCount(3); tbStd->setHorizontalHeaderLabels({"Roll No","Name","Login ID"});
    tbFac = new QTableWidget(); tbFac->setColumnCount(2); tbFac->setHorizontalHeaderLabels({"Emp ID","Name"});
    tbStd->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch); tbFac->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tbStd->setAlternatingRowColors(true); tbFac->setAlternatingRowColors(true);

    ll->addWidget(new QLabel("Registered Students:")); ll->addWidget(tbStd);
    ll->addWidget(new QLabel("Registered Faculty:")); ll->addWidget(tbFac);

    // Right
    QWidget *right = new QWidget(); QVBoxLayout *rl = new QVBoxLayout(right); right->setFixedWidth(350);

    QGroupBox *gs = new QGroupBox("Manage Students"); QFormLayout *fs = new QFormLayout(gs);
    inStdID = new QLineEdit(); inStdName = new QLineEdit(); inStdPass = new QLineEdit(); inDelStd = new QLineEdit();
    QPushButton *ba = new QPushButton("Add Student"); ba->setObjectName("AddBtn");
    QPushButton *br = new QPushButton("Remove ID"); br->setObjectName("DelBtn");
    fs->addRow("ID:", inStdID); fs->addRow("Name:", inStdName); fs->addRow("Pass:", inStdPass); fs->addRow(ba);
    fs->addRow("Remove ID:", inDelStd); fs->addRow(br);

    QGroupBox *gf = new QGroupBox("Manage Faculty"); QFormLayout *ff = new QFormLayout(gf);
    inFacID = new QLineEdit(); inFacName = new QLineEdit(); inFacPass = new QLineEdit(); inDelFac = new QLineEdit();
    QPushButton *ba2 = new QPushButton("Add Faculty"); ba2->setObjectName("AddBtn");
    QPushButton *br2 = new QPushButton("Remove ID"); br2->setObjectName("DelBtn");
    ff->addRow("ID:", inFacID); ff->addRow("Name:", inFacName); ff->addRow("Pass:", inFacPass); ff->addRow(ba2);
    ff->addRow("Remove ID:", inDelFac); ff->addRow(br2);

    rl->addWidget(gs); rl->addWidget(gf); rl->addStretch();
    l->addWidget(left); l->addWidget(right);

    connect(ba, &QPushButton::clicked, this, &AdminDashboard::addStudent);
    connect(br, &QPushButton::clicked, this, &AdminDashboard::removeStudent);
    connect(ba2, &QPushButton::clicked, this, &AdminDashboard::addFaculty);
    connect(br2, &QPushButton::clicked, this, &AdminDashboard::removeFaculty);

    tabs->addTab(w, "Users Management");
}

// ... (Baqi functions wese hi rahenge jese pehle thay, bas logic call karni hai)
// Do you need the Logic functions again or can you use the previous message?
// Just incase, here are the logic functions again to complete the file:

void AdminDashboard::addStudent() {
    if(sys->addStudent(inStdID->text().toStdString(), inStdName->text().toStdString(), inStdID->text().toStdString(), inStdPass->text().toStdString())) {
        refreshAll(); inStdID->clear(); inStdName->clear(); inStdPass->clear();
        QMessageBox::information(this,"Success","Student Added");
    } else QMessageBox::warning(this,"Error","Failed");
}
void AdminDashboard::removeStudent() {
    if(sys->removeStudent(inDelStd->text().toStdString())) { refreshAll(); QMessageBox::information(this,"Success","Removed"); }
    else QMessageBox::warning(this,"Error","Not Found");
}
void AdminDashboard::addFaculty() {
    if(sys->addFaculty(inFacID->text().toStdString(), inFacName->text().toStdString(), inFacID->text().toStdString(), inFacPass->text().toStdString())) {
        refreshAll(); inFacID->clear(); inFacName->clear(); inFacPass->clear();
        QMessageBox::information(this,"Success","Faculty Added");
    } else QMessageBox::warning(this,"Error","Failed");
}
void AdminDashboard::removeFaculty() {
    if(sys->removeFaculty(inDelFac->text().toStdString())) { refreshAll(); QMessageBox::information(this,"Success","Removed"); }
    else QMessageBox::warning(this,"Error","Not Found");
}

void AdminDashboard::setupCoursesTab() {
    QWidget *w = new QWidget(); QHBoxLayout *l = new QHBoxLayout(w);
    tbCourse = new QTableWidget(); tbCourse->setColumnCount(3); tbCourse->setHorizontalHeaderLabels({"Code","Name","Teacher"});
    tbCourse->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    tbCourse->setAlternatingRowColors(true);

    QWidget *right = new QWidget(); QVBoxLayout *rl = new QVBoxLayout(right); right->setFixedWidth(350);
    QGroupBox *gc = new QGroupBox("Manage Courses"); QFormLayout *fc = new QFormLayout(gc);
    inCourseCode = new QLineEdit(); inCourseName = new QLineEdit(); inDelCourse = new QLineEdit();
    QPushButton *ba = new QPushButton("Create Course"); ba->setObjectName("AddBtn");
    QPushButton *br = new QPushButton("Delete Course"); br->setObjectName("DelBtn");
    fc->addRow("Code:", inCourseCode); fc->addRow("Name:", inCourseName); fc->addRow(ba);
    fc->addRow("Remove Code:", inDelCourse); fc->addRow(br);

    rl->addWidget(gc); rl->addStretch();
    l->addWidget(tbCourse); l->addWidget(right);

    connect(ba, &QPushButton::clicked, this, &AdminDashboard::addCourse);
    connect(br, &QPushButton::clicked, this, &AdminDashboard::removeCourse);
    tabs->addTab(w, "Course Management");
}

void AdminDashboard::addCourse() {
    if(sys->addSubject(inCourseCode->text().toStdString(), inCourseName->text().toStdString())) {
        refreshAll(); inCourseCode->clear(); inCourseName->clear();
        QMessageBox::information(this,"Success","Course Created");
    } else QMessageBox::warning(this,"Error","Failed");
}
void AdminDashboard::removeCourse() {
    if(sys->removeSubject(inDelCourse->text().toStdString())) { refreshAll(); QMessageBox::information(this,"Success","Removed"); }
    else QMessageBox::warning(this,"Error","Not Found");
}

void AdminDashboard::setupAllocTab() {
    QWidget *w = new QWidget(); QVBoxLayout *l = new QVBoxLayout(w);

    QGroupBox *ga = new QGroupBox("Assign Teacher"); QHBoxLayout *ha = new QHBoxLayout(ga);
    cbAssignCourse = new QComboBox(); cbAssignFac = new QComboBox();
    QPushButton *ba = new QPushButton("Assign"); ba->setObjectName("AddBtn");
    ha->addWidget(new QLabel("Course:")); ha->addWidget(cbAssignCourse);
    ha->addWidget(new QLabel("Teacher:")); ha->addWidget(cbAssignFac); ha->addWidget(ba);

    QGroupBox *ge = new QGroupBox("Enroll Student"); QHBoxLayout *he = new QHBoxLayout(ge);
    inEnrollStd = new QLineEdit(); cbEnrollCourse = new QComboBox();
    QPushButton *be = new QPushButton("Enroll"); be->setObjectName("AddBtn");
    he->addWidget(new QLabel("Student ID:")); he->addWidget(inEnrollStd);
    he->addWidget(new QLabel("Course:")); he->addWidget(cbEnrollCourse); he->addWidget(be);

    l->addWidget(ga); l->addWidget(ge); l->addStretch();

    connect(ba, &QPushButton::clicked, this, &AdminDashboard::assignCourse);
    connect(be, &QPushButton::clicked, this, &AdminDashboard::enrollStudent);
    tabs->addTab(w, "Operations");
}

void AdminDashboard::assignCourse() {
    if(sys->assignSub(cbAssignCourse->currentText().toStdString(), cbAssignFac->currentText().toStdString())) {
        refreshAll(); QMessageBox::information(this,"Success","Assigned");
    } else QMessageBox::warning(this,"Error","Failed");
}
void AdminDashboard::enrollStudent() {
    if(sys->enrollStudent(inEnrollStd->text().toStdString(), cbEnrollCourse->currentText().toStdString())) {
        refreshAll(); QMessageBox::information(this,"Success","Enrolled");
    } else QMessageBox::warning(this,"Error","Failed");
}
