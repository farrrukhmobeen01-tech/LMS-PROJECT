#ifndef STUDENTDASHBOARD_H
#define STUDENTDASHBOARD_H

#include <QDialog>
#include <QTabWidget>
#include <QTableWidget>
#include <QListWidget>
#include <QComboBox>
#include <QLineEdit>
#include <QLabel>
#include "Portal.h"

class StudentDashboard : public QDialog
{
    Q_OBJECT

public:
    explicit StudentDashboard(Portal *system, int index, QWidget *parent = nullptr);
    ~StudentDashboard();

private:
    Portal *sys;
    int stdIndex;
    QTabWidget *tabs;

    void setupProfileTab();
    void setupCoursesTab();
    void setupAttendanceTab();
    void setupGradesTab();
    void setupContentTab();
    void setupFeedbackTab();
};

#endif // STUDENTDASHBOARD_H
