#ifndef ADMINDASHBOARD_H
#define ADMINDASHBOARD_H

#include <QDialog>
#include <QTabWidget>
#include <QLineEdit>
#include <QTableWidget>
#include <QComboBox>
#include "Portal.h"

class AdminDashboard : public QDialog
{
    Q_OBJECT

public:
    explicit AdminDashboard(Portal *system, QWidget *parent = nullptr);
    ~AdminDashboard();

private slots:
    void addStudent();
    void removeStudent();
    void addFaculty();
    void removeFaculty();
    void addCourse();
    void removeCourse();
    void assignCourse();
    void enrollStudent();
    void refreshAll();

private:
    Portal *sys;
    QTabWidget *tabs;

    // UI Elements
    QTableWidget *tbStd, *tbFac, *tbCourse;
    QLineEdit *inStdID, *inStdName, *inStdPass;
    QLineEdit *inFacID, *inFacName, *inFacPass;
    QLineEdit *inCourseCode, *inCourseName;
    QLineEdit *inDelStd, *inDelFac, *inDelCourse;

    QComboBox *cbAssignCourse, *cbAssignFac;
    QLineEdit *inEnrollStd;
    QComboBox *cbEnrollCourse;

    void setupUsersTab();
    void setupCoursesTab();
    void setupAllocTab();
};

#endif // ADMINDASHBOARD_H
