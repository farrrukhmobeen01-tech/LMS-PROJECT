#include "studentdashboard.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFormLayout>
#include <QPushButton>
#include <QHeaderView>
#include <QMessageBox>

StudentDashboard::StudentDashboard(Portal *system, int index, QWidget *parent)
    : QDialog(parent), sys(system), stdIndex(index)
{
    setWindowState(Qt::WindowMaximized); // FULL SCREEN

    setStyleSheet(R"(
        QDialog { background-color: #F4F7F6; }

        /* Tabs Styling */
        QTabWidget::pane { border: 1px solid #C0C0C0; background: white; border-radius: 5px; }
        QTabBar::tab {
            background: #E0E0E0; color: #333; padding: 12px 25px;
            font-size: 16px; font-weight: bold; margin-right: 2px;
            border-top-left-radius: 5px; border-top-right-radius: 5px;
        }
        QTabBar::tab:selected { background: #00796B; color: white; } /* Teal Color */

        /* Tables */
        QTableWidget {
            background: white; font-size: 15px; border: none; padding: 10px;
            selection-background-color: #B2DFDB; selection-color: black;
        }
        QHeaderView::section {
            background-color: #004D40; color: white; padding: 10px;
            font-size: 16px; font-weight: bold; border: none;
        }

        /* Buttons & Inputs */
        QPushButton {
            background-color: #00796B; color: white; font-size: 16px; font-weight: bold;
            padding: 10px 20px; border-radius: 5px;
        }
        QPushButton:hover { background-color: #004D40; }

        QLabel { font-size: 16px; color: #333; }
        QLineEdit, QComboBox { padding: 8px; font-size: 15px; border: 1px solid #ccc; border-radius: 4px; }
    )");

    setWindowTitle("Student Portal");

    QVBoxLayout *main = new QVBoxLayout(this);
    main->setContentsMargins(20, 20, 20, 20);

    // --- Header ---
    QHBoxLayout *top = new QHBoxLayout();
    QLabel *lbl = new QLabel("Student Dashboard  |  " + QString::fromStdString(sys->students[stdIndex].fullName));
    lbl->setStyleSheet("font-size: 26px; font-weight: 900; color: #004D40;");

    QPushButton *out = new QPushButton("LOGOUT");
    out->setStyleSheet("background-color: #C62828; color: white; font-weight: bold;");
    connect(out, &QPushButton::clicked, this, &QDialog::accept);

    top->addWidget(lbl); top->addStretch(); top->addWidget(out);
    main->addLayout(top);
    main->addSpacing(15);

    // --- Tabs ---
    tabs = new QTabWidget();
    tabs->setStyleSheet("font-size: 14px;"); // Base font for tabs content

    setupProfileTab();
    setupCoursesTab();
    setupAttendanceTab();
    setupGradesTab();
    setupContentTab();
    setupFeedbackTab();

    main->addWidget(tabs);
}

StudentDashboard::~StudentDashboard() {}

void StudentDashboard::setupProfileTab() {
    QWidget *tab = new QWidget();
    QFormLayout *form = new QFormLayout(tab);
    form->setContentsMargins(50, 50, 50, 50);
    form->setSpacing(25);

    Student &s = sys->students[stdIndex];

    QLabel *title = new QLabel("MY PROFILE");
    title->setStyleSheet("font-size: 22px; font-weight: bold; color: #00796B; margin-bottom: 20px;");

    auto createDetail = [](QString val) {
        QLabel *l = new QLabel(val);
        l->setStyleSheet("font-size: 18px; color: #333; padding: 10px; background: #E0F2F1; border-radius: 5px;");
        return l;
    };

    form->addRow(title);
    form->addRow("Full Name:", createDetail(QString::fromStdString(s.fullName)));
    form->addRow("Roll Number:", createDetail(QString::fromStdString(s.rollNo)));
    form->addRow("Username:", createDetail(QString::fromStdString(s.getID())));
    form->addRow("Enrolled Courses:", createDetail(QString::number(s.subCount)));

    tabs->addTab(tab, "Profile");
}

void StudentDashboard::setupCoursesTab() {
    QWidget *tab = new QWidget(); QVBoxLayout *l = new QVBoxLayout(tab);
    QTableWidget *t = new QTableWidget();
    t->setColumnCount(2);
    t->setHorizontalHeaderLabels({"Course Code", "Course Title"});
    t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    t->setAlternatingRowColors(true);

    Student &s = sys->students[stdIndex];
    t->setRowCount(s.subCount);
    for(int i=0; i<s.subCount; i++) {
        int ci = sys->findSubject(s.mySubs[i]);
        string name = (ci!=-1) ? sys->subjects[ci].subName : "Unknown";
        t->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(s.mySubs[i])));
        t->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(name)));
    }
    l->addWidget(t);
    tabs->addTab(tab, "Courses");
}

void StudentDashboard::setupAttendanceTab() {
    QWidget *tab = new QWidget(); QVBoxLayout *l = new QVBoxLayout(tab);
    QTableWidget *t = new QTableWidget();
    t->setColumnCount(3);
    t->setHorizontalHeaderLabels({"Subject", "Total Classes", "Classes Attended"});
    t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    t->setAlternatingRowColors(true);

    Student &s = sys->students[stdIndex];
    t->setRowCount(s.subCount);
    for(int i=0; i<s.subCount; i++) {
        int ci = sys->findSubject(s.mySubs[i]);
        if(ci!=-1) {
            Subject &sub = sys->subjects[ci];
            int myIdx = sub.getStudentIndex(s.rollNo);
            t->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(sub.subName)));
            t->setItem(i, 1, new QTableWidgetItem(QString::number(sub.sessions)));
            t->setItem(i, 2, new QTableWidgetItem(myIdx!=-1 ? QString::number(sub.presence[myIdx]) : "N/A"));
        }
    }
    l->addWidget(t);
    tabs->addTab(tab, "Attendance");
}

void StudentDashboard::setupGradesTab() {
    QWidget *tab = new QWidget(); QVBoxLayout *l = new QVBoxLayout(tab);
    QTableWidget *t = new QTableWidget();
    t->setColumnCount(2);
    t->setHorizontalHeaderLabels({"Subject", "Obtained Grade"});
    t->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    t->setAlternatingRowColors(true);

    Student &s = sys->students[stdIndex];
    t->setRowCount(s.subCount);
    for(int i=0; i<s.subCount; i++) {
        int ci = sys->findSubject(s.mySubs[i]);
        if(ci!=-1) {
            string g = sys->subjects[ci].getScore(s.rollNo);
            t->setItem(i, 0, new QTableWidgetItem(QString::fromStdString(s.mySubs[i])));
            t->setItem(i, 1, new QTableWidgetItem(QString::fromStdString(g.empty() ? "Not Graded" : g)));
        }
    }
    l->addWidget(t);
    tabs->addTab(tab, "Grades");
}

void StudentDashboard::setupContentTab() {
    QWidget *tab = new QWidget(); QVBoxLayout *l = new QVBoxLayout(tab);
    QComboBox *combo = new QComboBox();
    Student &s = sys->students[stdIndex];
    for(int i=0; i<s.subCount; i++) combo->addItem(QString::fromStdString(s.mySubs[i]));

    QListWidget *list = new QListWidget();
    list->setStyleSheet("font-size: 16px; padding: 10px;");

    l->addWidget(new QLabel("Select Course:")); l->addWidget(combo);
    l->addWidget(new QLabel("Lectures & Assignments:")); l->addWidget(list);

    connect(combo, &QComboBox::currentTextChanged, tab, [=](){
        list->clear();
        int ci = sys->findSubject(combo->currentText().toStdString());
        if(ci!=-1) {
            for(int i=0; i<sys->subjects[ci].noteCount; i++)
                list->addItem("📄 Lecture: " + QString::fromStdString(sys->subjects[ci].notes[i]));
            for(int i=0; i<sys->subjects[ci].taskCount; i++)
                list->addItem("📝 Assignment: " + QString::fromStdString(sys->subjects[ci].tasks[i]));
        }
    });
    if(s.subCount > 0) emit combo->currentTextChanged(combo->currentText());
    tabs->addTab(tab, "Course Content");
}

void StudentDashboard::setupFeedbackTab() {
    QWidget *tab = new QWidget(); QVBoxLayout *l = new QVBoxLayout(tab);
    QComboBox *combo = new QComboBox();
    Student &s = sys->students[stdIndex];
    for(int i=0; i<s.subCount; i++) combo->addItem(QString::fromStdString(s.mySubs[i]));

    QLineEdit *inMsg = new QLineEdit(); inMsg->setPlaceholderText("Write your feedback here...");
    QPushButton *btn = new QPushButton("Send Feedback");

    l->addWidget(new QLabel("Select Course:")); l->addWidget(combo);
    l->addWidget(new QLabel("Your Message:")); l->addWidget(inMsg);
    l->addWidget(btn); l->addStretch();

    connect(btn, &QPushButton::clicked, tab, [=](){
        int ci = sys->findSubject(combo->currentText().toStdString());
        if(ci!=-1 && !inMsg->text().isEmpty()) {
            string msg = sys->students[stdIndex].fullName + ": " + inMsg->text().toStdString();
            sys->subjects[ci].addReview(msg);
            QMessageBox::information(this,"Sent","Feedback submitted successfully.");
            inMsg->clear();
        }
    });
    tabs->addTab(tab, "Feedback");
}
