#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QComboBox>
#include "Portal.h" // Tumhari backend logic file

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void handleLogin(); // Ye function tab chalega jab button dabega

private:
    // UI Elements (jo screen par nazar ayenge)
    QLineEdit *inputID;
    QLineEdit *inputPass;
    QComboBox *comboRole;

    // Backend System
    Portal sys;
};
#endif // MAINWINDOW_H
