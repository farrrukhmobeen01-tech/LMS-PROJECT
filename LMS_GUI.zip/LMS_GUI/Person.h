#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class Portal; // Forward declaration

class Person {
protected:
    string uID;      // Login ID
    string passKey;  // Password

public:
    Person();
    virtual ~Person();

    // Auth Functions
    void setAuth(const string& u, const string& p);
    bool verifyAuth(const string& u, const string& p) const;
    string getID() const;

    // Virtual Functions (Child classes must implement)
    virtual string getType() const = 0;
    virtual void showMenu(Portal& sys, int idx) = 0;

    // File Handling Helpers
    void saveAuth(ofstream& out) const;
    void loadAuth(ifstream& in);
};

#endif // PERSON_H
