#include "mainwindow.h"
#include "studentdashboard.h"
#include "facultydashboard.h"
#include "admindashboard.h"
#include <QVBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QFrame>
#include <QGraphicsDropShadowEffect>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    sys.loadAll();

    setWindowTitle("LMS - Bahria University");
    setWindowState(Qt::WindowMaximized);

    // --- UPDATED STYLING (Button Fix) ---
    setStyleSheet(R"(
        QMainWindow { background-color: #E8EFF5; }
        QLabel { font-family: 'Segoe UI', sans-serif; color: #2C3E50; }

        QFrame#LoginFrame {
            background-color: #FFFFFF;
            border-radius: 15px;
            border: 1px solid #D6D6D6;
        }

        QLineEdit, QComboBox {
            border: 2px solid #E0E0E0; border-radius: 8px; padding: 10px;
            font-size: 15px; background: #FAFAFA; color: #333;
        }
        QLineEdit:focus, QComboBox:focus { border: 2px solid #3498DB; background: #FFFFFF; }

        /* BUTTON FIX: Padding thori kam ki hai taake text na katay */
        QPushButton {
            background-color: #2980B9; color: white; font-weight: bold; font-size: 16px;
            border-radius: 8px; padding: 12px; min-height: 25px;
        }
        QPushButton:hover { background-color: #1A5276; }
        QPushButton:pressed { background-color: #154360; }
    )");

    QWidget *centralWidget = new QWidget(this);
    setCentralWidget(centralWidget);

    QGridLayout *layout = new QGridLayout(centralWidget);

    // --- LOGIN CARD ---
    QFrame *loginFrame = new QFrame();
    loginFrame->setObjectName("LoginFrame");
    loginFrame->setFixedSize(420, 520); // Height thori adjust ki

    QGraphicsDropShadowEffect *shadow = new QGraphicsDropShadowEffect();
    shadow->setBlurRadius(20);
    shadow->setColor(QColor(0, 0, 0, 50));
    shadow->setOffset(0, 5);
    loginFrame->setGraphicsEffect(shadow);

    QVBoxLayout *frameLayout = new QVBoxLayout(loginFrame);
    frameLayout->setSpacing(15);
    frameLayout->setContentsMargins(40, 40, 40, 40);

    // Header
    QLabel *header = new QLabel("BAHRIA UNIVERSITY");
    header->setAlignment(Qt::AlignCenter);
    header->setStyleSheet("font-size: 26px; font-weight: 900; color: #1A5276; margin-bottom: 5px;");

    QLabel *subHeader = new QLabel("LMS PORTAL");
    subHeader->setAlignment(Qt::AlignCenter);
    subHeader->setStyleSheet("font-size: 14px; font-weight: bold; color: #7F8C8D; margin-bottom: 20px; letter-spacing: 2px;");

    // Inputs
    QLabel *lblRole = new QLabel("Select Role"); lblRole->setStyleSheet("font-size: 13px; font-weight: bold; color: #555;");
    comboRole = new QComboBox();
    comboRole->addItems({"Select Role...", "Student", "Faculty", "Admin"});
    comboRole->setCursor(Qt::PointingHandCursor);

    QLabel *lblUser = new QLabel("User ID"); lblUser->setStyleSheet("font-size: 13px; font-weight: bold; color: #555;");
    inputID = new QLineEdit();
    inputID->setPlaceholderText("e.g. 01-134191-001");

    QLabel *lblPass = new QLabel("Password"); lblPass->setStyleSheet("font-size: 13px; font-weight: bold; color: #555;");
    inputPass = new QLineEdit();
    inputPass->setPlaceholderText("••••••••");
    inputPass->setEchoMode(QLineEdit::Password);

    QPushButton *btnLogin = new QPushButton("SECURE LOGIN");
    btnLogin->setCursor(Qt::PointingHandCursor);

    frameLayout->addWidget(header);
    frameLayout->addWidget(subHeader);
    frameLayout->addWidget(lblRole);
    frameLayout->addWidget(comboRole);
    frameLayout->addWidget(lblUser);
    frameLayout->addWidget(inputID);
    frameLayout->addWidget(lblPass);
    frameLayout->addWidget(inputPass);
    frameLayout->addSpacing(10);
    frameLayout->addWidget(btnLogin);
    frameLayout->addStretch();

    layout->addWidget(loginFrame, 0, 0, Qt::AlignCenter);

    connect(btnLogin, &QPushButton::clicked, this, &MainWindow::handleLogin);
}

MainWindow::~MainWindow() { sys.saveAll(); }

void MainWindow::handleLogin()
{
    string uID = inputID->text().toStdString();
    string pass = inputPass->text().toStdString();
    int roleIdx = comboRole->currentIndex();

    bool success = false;
    string roleName = "";
    int idx = -1;

    if (roleIdx == 3) { // Admin
        if (sys.admin.verifyAuth(uID, pass)) { success = true; roleName = "Admin"; }
    }
    else if (roleIdx == 2) { // Faculty
        idx = sys.findFacultyUser(uID);
        if (idx != -1 && sys.facList[idx].verifyAuth(uID, pass)) { success = true; roleName = "Faculty"; }
    }
    else if (roleIdx == 1) { // Student
        idx = sys.findStudentUser(uID);
        if (idx != -1 && sys.students[idx].verifyAuth(uID, pass)) { success = true; roleName = "Student"; }
    }

    if (success) {
        this->hide();
        if (roleName == "Student") { StudentDashboard d(&sys, idx); d.exec(); }
        else if (roleName == "Faculty") { FacultyDashboard d(&sys, idx); d.exec(); }
        else if (roleName == "Admin") { AdminDashboard d(&sys); d.exec(); }

        this->show();
        inputPass->clear();
    } else {
        QMessageBox::warning(this, "Access Denied", "Incorrect Credentials or Role!");
    }
}
